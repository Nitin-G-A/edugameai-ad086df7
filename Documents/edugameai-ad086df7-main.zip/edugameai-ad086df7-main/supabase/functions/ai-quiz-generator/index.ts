import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation helper
function validateInput(body: unknown): { topic: string; difficulty: string; numQuestions: number } | null {
  if (!body || typeof body !== 'object') return null;
  
  const data = body as Record<string, unknown>;
  
  // Validate topic (optional, default to general knowledge)
  const topic = typeof data.topic === 'string' && data.topic.length > 0 && data.topic.length <= 500 
    ? data.topic 
    : "general knowledge";
  
  // Validate difficulty
  const validDifficulties = ['easy', 'medium', 'hard'];
  const difficulty = typeof data.difficulty === 'string' && validDifficulties.includes(data.difficulty)
    ? data.difficulty
    : "medium";
  
  // Validate numQuestions (1-20)
  let numQuestions = 5;
  if (typeof data.numQuestions === 'number') {
    numQuestions = Math.min(20, Math.max(1, Math.floor(data.numQuestions)));
  }
  
  return { topic, difficulty, numQuestions };
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const body = await req.json();
    
    // Validate input
    const validatedInput = validateInput(body);
    if (!validatedInput) {
      return new Response(JSON.stringify({ error: "Invalid input parameters" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    
    const { topic, difficulty, numQuestions } = validatedInput;
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: "You generate educational quiz questions for higher education students." },
          { role: "user", content: `Generate ${numQuestions} ${difficulty} difficulty multiple choice questions about "${topic}". Make sure each question has exactly 4 options.` },
        ],
        tools: [{
          type: "function",
          function: {
            name: "generate_quiz",
            parameters: {
              type: "object",
              properties: {
                questions: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      question: { type: "string" },
                      options: { type: "array", items: { type: "string" } },
                      correctAnswer: { type: "number", description: "0-based index of correct option" },
                      explanation: { type: "string" },
                    },
                    required: ["question", "options", "correctAnswer", "explanation"],
                  },
                },
              },
              required: ["questions"],
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "generate_quiz" } },
      }),
    });

    if (!response.ok) throw new Error("AI request failed");

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    const result = toolCall ? JSON.parse(toolCall.function.arguments) : { questions: [] };

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
